package com.rslakra.imageservice.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Author: Rohtash Singh Lakra
 * Created: 2019-03-05 10:22
 */
public enum Role {
    USER, ADMIN;
}
