#!/usr/bin/env python
#Sum of 2 numbers
num1 = 23
num2 = 43

def sumNumbers(number1, number2):
	return number1 + number2
sum = sumNumbers(num1, num2)
print "Sum of "
print num1
print " and "
print num2
print " = "
print sum
#print "Sum of " + num1 + " and " + num2 + " = " + sum
