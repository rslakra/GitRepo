import random

def line(length):
    for i in range(length):
        print "-",
        #return;

for i in range(10):
    rNumber = random.random()
    print rNumber
    

line(10)
print "\nRandom between 5 to 10"

line(10)
print
print random.randint(5, 10)