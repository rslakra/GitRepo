#!/usr/bin/env python
x, y = 3, 6
print x + y
x + 3
print x

odds = [1, 3, 5, 7, 9]
evens = odds
evens.append(11)
print odds
