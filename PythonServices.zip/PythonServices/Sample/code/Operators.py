#!/usr/bin/env python
#Operators

#Boolean test weather a value is inside the container
values = [1, 2, 3, 4, 5]
print values
print 3 in values
print 6 in values
print

#For strings, tests for substrings
str = "Rohtash Singh Lakra"
print str
print 'Singh' in str
print 'Python' in str

