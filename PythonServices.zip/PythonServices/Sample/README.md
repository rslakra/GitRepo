# Python
This repository contains the python project.


```
Sample/
|-- code/
|   |-- __init__.py
|   |-- main.py
|
|-- docs/
|   |-- init.txt
|
|-- scripts/
|   |-- build.sh
|
|-- tests/
|   |-- __init__.py
|   |-- test_main.py
|
|-- setup.py
|-- README
```




Sample Module Repository
========================

This simple project is an example repo for Python projects.

`Learn more <http://www.kennethreitz.org/essays/repository-structure-and-python>`_.

---------------


# Author
- Rohtash Lakra