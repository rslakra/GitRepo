# DQ (Data Quality) VAT Validation Process

These scripts are created to resolve the following jira tikcet.
- [GEMINIAPP-17456](https://jira.vzbuilders.com/browse/GEMINIAPP-17456)

## Environment
```
python -V #Python 3.8.3
pip install openpyxl
```

DQ team will send an email that they have updated the [VAT validation sheet](https://docs.google.com/spreadsheets/d/1eka26S1zOcE1q9EQCtXjtqpHIIuJ7Qv_yTbuRO5XvP8/edit#gid=0).
Download it locally and copy at ```<your source folder path>/PyScripts/code/dq/``` folder.

## Generate Payload to update advertisers

- Run the python script ```excel2JsonGeneratorDQ_VATValidationProcess.py```.

    The script reads ```EMEA SSELF VAT Check.xlsx``` file and saves results into ```vatValidationPayload.json``` file.

The following end-points consumes the above generated payload.

- Open [Admin UI](https://gemini.yahoo.com/internal/advertiser/admin) Page
- Update Advertisers
  - Entity: ```advertiser/batch```
  - Method: ```PUT```
  - Params:
  - JSON:
    ```json
    [
        {
            "address": {
                "addressLine1": "C/O The Accountancy Partnership, Ste 5, 5th Fl",
                "addressLine2": "City Reach, 5 Greenwich View Place",
                "city": "London",
                "country": "United Kingdom",
                "postalCode": "E14 9NN",
                "state": ""
            },
            "id": 2133618,
            "mdmAdvertiserName": "SA Apparel Ltd",
            "vatId": "GB341438809",
            "webSiteUrl": "https://www.amethystgothic.com"
        }
    ]
    ```

- Press ```Submit``` button.

All the advertisers, which payload is provided will be updated.

After updating the advertisers in db, please open the local sheet ```EMEA SSELF VAT Check.xlsx```, copy the column 'S' 
for all the rows that are updated today into [VAT validation sheet](https://docs.google.com/spreadsheets/d/1eka26S1zOcE1q9EQCtXjtqpHIIuJ7Qv_yTbuRO5XvP8/edit#gid=0).

Then send an email back to DQ team that DB has updated so that they can verify  the updates.


# Author

- Rohtash Singh Lakra
