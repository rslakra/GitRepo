import json
from datetime import datetime

from openpyxl import load_workbook

REMOVE_VAT_FROM_GEMINI = 'Remove VAT# from Gemini'
ACCOUNT_NOT_EXIST = 'Account doesn\'t exist in SFDC'
TIME_NOW = datetime.now().strftime("%Y/%m/%d %H:%M:%S")


# mapping = {
#     'AB':( 'id',)
#     'J': ('mdmAdvertiserName', 'Legal Name')
#     'K': ('address.addressLine1', 'Address Line 1')
#     'L': ('address.addressLine2', 'Address Line 2')
#     'M': ('address.city', 'City')
#     'N': ('address.state', 'Province/State')
#     'O': ('address.postalCode', 'Zip/Postal Code')
#     'P': ('address.country', 'Country')
#     'Q': ('vatId', 'VAT/TAX ID')
#     'R': ('webSiteUrl', 'Website',)
#     'S': ('geminiTeamComments', 'Gemini Team Comments')
#     'T': ('taxTeamComments', 'TAX team Comments')
# }

def buildExcel2Json(file_path, tab_name, output_path):
    wb = load_workbook(filename=file_path)
    ws = wb[tab_name]

    totalRows = len(ws['A'])
    print(f'totalRows: {totalRows}')

    jsonList = []

    for row in range(totalRows):
        if row == 0: continue  # skip the first line (column name)

        # skip which are not verified yet by DQ Team (means Column T is empty)
        taxTeamComments = ws['T'][row].value
        # print(f'Processing taxTeamComments: {taxTeamComments}')
        if None == taxTeamComments:
            print(f'Skipping Row: {row + 1}')
            continue

        # skip which are already processed (means column S is updated by script)
        geminiTeamComments = ws['S'][row].value
        # print(f'Processing geminiTeamComments: {geminiTeamComments}')
        if geminiTeamComments:
            print(f'Skipping Row: {row + 1}')
            continue

        # check id
        id = ws['AB'][row].value
        if id == ACCOUNT_NOT_EXIST or not id: continue
        id = int(id)

        # skip empty vatId
        vatId = ws['Q'][row].value
        if isinstance(vatId, float) or isinstance(vatId, int): vatId = str(int(vatId))
        if not vatId: continue

        print(f'Processing Row: {row + 1}, advertiserId: {id}, vatId: {vatId}')

        if vatId == REMOVE_VAT_FROM_GEMINI:
            jsonList.append(removeVatIdJson(ws, row))
            updateExcelSheetComments(ws, row, 'VAT_ID Removed')
        else:
            jsonList.append(updateJson(ws, row))
            updateExcelSheetComments(ws, row, 'Record Updated')

        # updateExcelWithTime(ws, row)

    with open(output_path, 'w') as output:
        json.dump(jsonList, output, indent=4, sort_keys=True)

    wb.save(filename=file_path)


def removeVatIdJson(ws, row):
    jsonPayload = {}
    jsonPayload['id'] = int(ws['AB'][row].value)
    jsonPayload['vatId'] = ""
    return jsonPayload


def updateJson(ws, row):
    id = int(ws['AB'][row].value)
    mdmAdvertiserName = ws['J'][row].value
    webSiteUrl = ws['R'][row].value
    vatId = ws['Q'][row].value
    addressLine1 = ws['K'][row].value
    addressLine2 = ws['L'][row].value
    city = ws['M'][row].value
    state = ws['N'][row].value
    postalCode = ws['O'][row].value
    country = ws['P'][row].value

    # print(f'Row: {row + 1}, addressLine1: {addressLine1}, addressLine2: {addressLine2}, city: {city}, state: {state}, postalCode: {postalCode}, country: {country}')

    if isinstance(vatId, float) or isinstance(vatId, int): vatId = str(int(vatId))
    if isinstance(postalCode, float) or isinstance(postalCode, int): postalCode = str(int(postalCode))

    address = {}
    address['addressLine1'] = addressLine1 if addressLine1 != None else ""
    address['addressLine2'] = addressLine2 if addressLine2 != None else ""
    address['city'] = city if city != None else ""
    address['state'] = state if state != None else ""
    address['postalCode'] = postalCode if postalCode != None else ""
    address['country'] = country if country != None else ""
    # print(f'Row: {row + 1}, id: {id}, mdmAdvertiserName: {mdmAdvertiserName}, vatId: {vatId}, webSiteUrl: {webSiteUrl}, address: {address}')

    jsonPayload = {}
    if id: jsonPayload['id'] = id
    jsonPayload['mdmAdvertiserName'] = mdmAdvertiserName if mdmAdvertiserName != None else ""
    if vatId: jsonPayload['vatId'] = vatId
    jsonPayload['webSiteUrl'] = webSiteUrl if webSiteUrl != None else ""
    if address: jsonPayload['address'] = address

    return jsonPayload


def updateExcelSheetComments(ws, row, comments):
    message = comments + "-" + TIME_NOW
    # ws['S'][row].value = TIME_NOW
    ws['S'][row].value = message


if __name__ == "__main__":
    print('Processing Excel Sheet ...')
    # getJsonList('test.xlsx', 'Sheet1', 'test.json')
    buildExcel2Json('EMEA SSELF VAT Check.xlsx', 'SSELF with VAT', 'vatValidationPayload.json')
    print('Processing Completed!')
