import csv
import json


# Double Quotes Dictionary
class doubleQuoteDictionary(dict):
    def __str__(self):
        return json.dumps(self)

    def __repr__(self):
        return json.dumps(self)


# Builds the .json from the .csv file.
def buildJson(csvFilePath, resultFilePath):
    data = []
    # Read file
    with open(csvFilePath, encoding='utf-8') as csvFile:
        csvReader = csv.DictReader(csvFile)
        record = {}
        for rows in csvReader:
            # Assuming a column named 'Gemini Advertiser Id'
            record["id"] = int(rows['Gemini Advertiser Id'])
            record["timezone"] = rows['Expected Timezone to Stamp in Gemini']
            # print(record)
            # print(DoubleQuoteDictionary(record))
            # append every row into data
            data.append(doubleQuoteDictionary(record))
    # close csv file.
    # csvFile.close()
    # data = doubleQuoteDictionary(data)
    print(data)
    # Write file
    with open(resultFilePath, 'w', encoding='utf-8') as resultFile:
        resultFile.write(json.dumps(data, indent=4))
    # close json file
    # jsonFile.close()


# build comma separated list.
def printCommaSeparatedList(csvFilePath):
    data = []
    # Read file
    with open(csvFilePath, encoding='utf-8') as csvFile:
        csvReader = csv.DictReader(csvFile)
        for rows in csvReader:
            data.append(int(rows['Gemini Advertiser Id']))

    # print results
    print(data)


# Starting Point
# print('Python %s on %s' % (sys.version, sys.platform))
csvFilePath = '/Users/rlakra/Downloads/UCAM-TimeZone-Update-WithAds-2020Aug18.csv'
jsonFilePath = '/Users/rlakra/Downloads/jsonTimeZonePayload.json'
buildJson(csvFilePath, jsonFilePath)

# print('Python %s on %s' % (sys.version, sys.platform))
printCommaSeparatedList(csvFilePath)
