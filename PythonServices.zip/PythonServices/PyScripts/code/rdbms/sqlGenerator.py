import csv
import json


# Builds the SQL Script generated from the .CSV file.
def buildSqlScript(csvFilePath, jsonFilePath):
    data = []
    # Read file
    with open(csvFilePath, encoding='utf-8') as csvFile:
        csvReader = csv.DictReader(csvFile)
        record = {}
        for rows in csvReader:
            # Assuming a column named 'No' to
            # be the primary key
            record["id"] = int(rows['Gemini Advertiser Id'])
            advertiserId = rows['Gemini Advertiser Id']
            record["timezone"] = str(rows['Expected Timezone to Stamp in Gemini'])
            # print(advertiserId + ", " + timeZoneExpected)
            print(record)

            # append every row into data
            data.append(record)

    # close csv file.
    csvFile.close()

    print(data)
    # Write file
    with open(jsonFilePath, 'w', encoding='utf-8') as jsonFile:
        jsonFile.write(json.dumps(data, indent=4))

    # close json file
    jsonFile.close()


# Starting Point
csvFilePath = r'/Users/rlakra/Downloads/UCAM-TimeZone-Update-WithAds-2020Aug18.csv'
jsonFilePath = r'/Users/rlakra/Downloads/jsonTimeZonePayload.json'
buildSqlScript(csvFilePath, jsonFilePath)
