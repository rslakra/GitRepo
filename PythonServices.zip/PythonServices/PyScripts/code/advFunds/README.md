# AdvertiserFunds

These scripts are created to resolve the following jira tikcet.
- [GEMINIAPP-17511](https://jira.vzbuilders.com/browse/GEMINIAPP-17511)

## Environment
```
python -V #Python 3.8.3
pip install openpyxl
```

## 1. Check An Advertiser Funds in Gemini UI

- [Advertiser ID=1351934](https://gemini.yahoo.com/internal/advertiser/1351934/billing)


## 2. Zero-out the balance of the Advertisers

- Execute the following query
```sql
select advertiser_id, funds, balance_owed, spend
from MB.advertiser_funds
where advertiser_id in (
        1723974
    )
ORDER BY created_date desc
;
```

- Save the results of the query into ```ZeroOutAdvertiserFunds.xlsx``` file.

- Run the python script ```zeroOutPayloadGenerator.py```.

    The script reads ```ZeroOutAdvertiserFunds.xlsx``` file and saves results into ```zeroOutPayload.json``` and ```adjustSpendCapPayload.json``` files.

The following end-points consumes the above generated payloads.

### Step 1 - Update Advertiser Funds

- Open [Admin UI](https://gemini.yahoo.com/internal/advertiser/admin) Page
- Update Advertisers
  - **Entity**: ```advertiserfunds/batch```
  - **Method**: ```PUT```
  - **Params**:
  - **JSON**: Copy the ```zeroOutPayload.json``` file contents into JSON body.
  
    ````json
    [
        {
            "accountSpendCap": 0,
            "advertiserId": 1723974,
            "balance": 0,
            "balanceOwed": 0,
            "funds": 263.73
        }
    ]
    ````

- Press ```Submit``` button.

For all advertisers, which payload is provided, the funds are replaced with spend and balance, balanceOwed and accountSpendCap set to 0 (zero).

### Step 2 - Adjust Spend Cap of Advertisers

- Open [Admin UI](https://gemini.yahoo.com/internal/advertiser/admin) Page
- Update Advertisers
  - **Entity**: ```advertiserfunds/adjust-payg-spendcap/batch```
  - **Method**: ```PUT```
  - **Params**:
  - **JSON**: Copy the ```adjustSpendCapPayload.json``` file contents into JSON body.

    ```json
    {
        "advertiserIds": [
            1723974
        ]
    }
    ```

- Press ```Submit``` button.

For all advertisers, which payload is provided, the balance, balanceOwed and accountSpendCap will be adjusted.


## 3. Generate Refund Payload

- Execute the following query
```sql
select id, advertiser_id, amount, created_date, charge_method
from MB.fund_transactions
where advertiser_id in (
        1723974
    )
    and charge_method = 'CHARGE'
    --and created_date >= '24-SEP-21'
ORDER BY charge_method desc, created_date desc
;
```

- Save the results of the query into ```RefundTransactions.xlsx``` file.

- Run the python script ```refundPayloadGenerator.py```.

    The script reads ```RefundTransactions.xlsx``` file and saves results into ```refundPayload.json``` file.

The following end-points consumes the above generated payload.

- Open [Admin UI](https://gemini.yahoo.com/internal/advertiser/admin) Page
- Update Advertisers
  - Entity: ```advertiserfunds/refund/batch```
  - Method: ```POST```
  - Params:
  - JSON:
    ```json
    [
        {
            "advertiserId": 1583344,
            "amount": 0.05,
            "reason": "GEMINIAPP-17511",
            "taxAmount": 0,
            "transactionId": 5203803
        }
    ]
    ```

- Press ```Submit``` button.

All the advertisers, which payload is provided will be refunded.

- Repeat the steps of [Zero-out the balance of the Advertisers](#2-zero-out-the-balance-of-the-advertisers)


# References

- [Advertiser Funds](https://git.vzbuilders.com/rlakra/TheApiGuide/blob/master/API/Gemini/AdvertiserFunds.md)
- 


# Author

- Rohtash Singh Lakra
