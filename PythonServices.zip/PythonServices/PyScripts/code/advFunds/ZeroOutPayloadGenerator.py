import json
from datetime import datetime
from openpyxl import load_workbook

TIME_NOW = datetime.now().strftime("%Y/%m/%d %H:%M:%S")

# Query
#
# select advertiser_id, funds, balance_owed, spend
# from MB.advertiser_funds
# where advertiser_id in (
#         1723974
#     )
# ORDER BY created_date desc
# ;
#
# mapping = {
#     'A':( 'advertiser_id',)
#     'B':( 'funds',)
#     'C':( 'balance_owed',)
#     'D':( 'spend',)
# }
#
# Response Payload
# [
#     {
#         "advertiserId": 73894,
#         "balance": 0,
#         "balanceOwed": 0,
#         "accountSpendCap": 0,
#         "funds": 9900.29
#     }
# ]

# returns true if the string is float otherwise false.
def is_float(str):
    try:
        float(str)
        return True
    except ValueError:
        return False



def saveResponse(outputPath, jsonPayloadList):
    with open(outputPath, 'w') as output:
        json.dump(jsonPayloadList, output, indent=4, sort_keys=True)


def buildExcel2Json(file_path, tab_name, zeroOutPayloadPath, adjustSpendCapPayloadPath):
    wb = load_workbook(filename=file_path)
    ws = wb[tab_name]

    totalRows = len(ws['A'])
    print(f'totalRows: {totalRows}')

    jsonZeroOutPayloadList = []
    jsonAdvertiserIdList = []

    for row in range(totalRows):
        if row == 0: continue  # skip the first line (column name)

        # skip if first column is empty
        advertiserId = ws['A'][row].value
        if not advertiserId:
            print(f'Skipping Row: {row + 1}')
            continue

        advertiserId = int(advertiserId)
        spend = ws['D'][row].value

        print(f'Processing Row: {row + 1}, advertiserId: {advertiserId}, spend: {spend}')
        jsonPayload = {}
        jsonPayload['advertiserId'] = advertiserId
        jsonPayload['balance'] = 0
        jsonPayload['balanceOwed'] = 0
        jsonPayload['accountSpendCap'] = 0
        # to zero-out balanceOwed, spend becomes the funds
        if is_float(spend):
            jsonPayload['funds'] = float(spend)
        else:
            jsonPayload['funds'] = float(0)

        # append payload
        jsonZeroOutPayloadList.append(jsonPayload)
        jsonAdvertiserIdList.append(advertiserId)

    # save jsonZeroOutPayloadList
    saveResponse(zeroOutPayloadPath, jsonZeroOutPayloadList)

    jsonAdjustSpendCapPayload = {}
    jsonAdjustSpendCapPayload['advertiserIds'] = jsonAdvertiserIdList
    # save jsonAdjustSpendCapPayloadList
    saveResponse(adjustSpendCapPayloadPath, jsonAdjustSpendCapPayload)
    # wb.save(filename=file_path)


if __name__ == "__main__":
    print('Processing Excel Sheet ...')
    # getJsonList('test.xlsx', 'Sheet1', 'test.json')
    buildExcel2Json('ZeroOutAdvertiserFunds.xlsx', 'Sheet1', 'zeroOutPayload.json', 'adjustSpendCapPayload.json')
    print('Processing Completed!')
