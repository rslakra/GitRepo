import json
from datetime import datetime

from openpyxl import load_workbook

TIME_NOW = datetime.now().strftime("%Y/%m/%d %H:%M:%S")
TIME_NOW_NUMERIC = datetime.now().strftime("%Y%m%d%H%M%S")

#
# Sales Provided Excel Sheet
#
# Column : Field Name {
#   'A' : Id                - Advertiser Id
#   'L' : Transaction ID    - Fund Transaction Id
#   'G' : Refund Amount     - Amount to refund to account
#   'X' : Reason            - Reason of Refund
#
def generate_refund_json_payload_from_excel(input_file_path, workbook_sheet, output_file_path, refund_reason_prefix):
    workbook = load_workbook(filename=input_file_path)
    sheet = workbook[workbook_sheet]

    total_rows = len(sheet['A'])
    print(f'total_rows: {total_rows}')

    json_records = []

    for row in range(total_rows):
        if row == 0:
            continue  # skip the first line (column name)

        # skip if first column is empty
        # 'A' : Advertiser Id
        advertiser_id = sheet['A'][row].value
        if not advertiser_id:
            print(f'Skipping Row: {row + 1}')
            continue

        # 'L' : Transaction ID
        transaction_id = sheet['L'][row].value
        # 'Q' : Refund Amount
        # refund_amount = sheet['G'][row].value
        # refund_amount = sheet['Q'][row].value
        refund_amount = sheet['P'][row].value
        # 'X' : Reason
        refund_reason = "".join([refund_reason_prefix, str(transaction_id)])

        # log record
        record = ','.join([':'.join(["advertiser_id", str(advertiser_id)]),
                           ':'.join(["transaction_id", str(transaction_id)]),
                           ':'.join(["amount", str(refund_amount)]),
                           ':'.join(["refund_reason", str(refund_reason)])])
        print(f'Processing Row: {row + 1}, {record}')

        # JSON Results
        # {
        #     "advertiserId": {{ADVERTISER_ID}},
        #     "amount": {{REFUND_AMOUNT}},
        #     "reason": "{{REFUND_REASON}}",
        #     "transactionId": {{FUND_TRANSACTION_ID}}
        # }
        json_payload = {}
        json_payload['advertiserId'] = int(advertiser_id)
        json_payload['amount'] = float(refund_amount)
        json_payload['transactionId'] = int(transaction_id)
        json_payload['reason'] = refund_reason
        json_payload['taxAmount'] = 0

        json_records.append(json_payload)

    with open(output_file_path, 'w') as output:
        json.dump(json_records, output, indent=4, sort_keys=True)

    # workbook.save(filename=file_path)


if __name__ == "__main__":
    print('Processing Excel Sheet ...')
    workbook_path = '/Users/rlakra/Downloads/WorkData/Zero-Out Balance/John McNamara/Lily'
    print(f'workbook_path: {workbook_path}')
    workbook_file_name = 'Bulk Refunds - Shared with Gemini for processing.xlsx'
    workbook_file_path = '/'.join([workbook_path, workbook_file_name])
    print(f'workbook_file_path: {workbook_file_path}')
    sheet_name = 'Batch-3-Partial-2024-02-21'
    print(f'sheet_name: {sheet_name}')
    json_file_path = '/'.join([workbook_path, '.'.join([sheet_name, 'json'])])
    print(f'json_file_path: {json_file_path}')
    reason_prefix = '-'.join(['GEMINIAPP-19185', 'Refund', str(TIME_NOW_NUMERIC), 'ftId#'])
    print(f'reason_prefix: {reason_prefix}')

    #
    # Call a function to generate json file from an excel workbook
    #
    # convert_excel_to_json('RefundTransactions.xlsx', 'Sheet1', 'refundPayload.json')

    generate_refund_json_payload_from_excel(workbook_file_path, sheet_name, json_file_path, reason_prefix)
    print('Processing Completed!')
