# coding: utf-8

from __future__ import unicode_literals

import codecs
import csv
import json

# Register Custom Delimiter
csv.register_dialect('unixpwd', delimiter='\t', quoting=csv.QUOTE_NONE)


# The csv file might contain very huge fields, therefore increase the field_size_limit
# And avoids error: _csv.Error: field larger than field limit (131072)
# csv.field_size_limit(sys.maxsize)


def audienceTargetingSQLGenerator(tableName, columns, sourceFilePath, targetFilePath):
    targetFile = codecs.open(targetFilePath, "w", "utf_8")

    indexRange = [0, 4, 10, 17]

    # INSERT INTO tableName(columns)
    # VALUES
    #     (value_list_1),
    #     (value_list_2),
    #     ...
    #     (value_list_n);
    # sqlStart = "INSERT INTO %s(%s) \nVALUES \n" % (tableName, ", ".join(columns))
    #
    # # write sql heading to file.
    # print("%s" % (sqlStart))
    # targetFile.write(sqlStart)

    try:
        # Read file
        with open(sourceFilePath, encoding='utf-8') as csvFile:
            # Read .CSV file
            # reader = csv.reader(csvFile, delimiter='\t')
            # reader = csv.reader(csvFile, delimiter='\t', quoting=csv.QUOTE_NONE)
            # _csv.Error: line contains NUL
            reader = csv.reader((line.replace('\0', '') for line in csvFile), delimiter='\t', quoting=csv.QUOTE_NONE)

            # Iterate entries of the file.
            for row in reader:
                values = []
                # print(row)
                rowLength = len(row)
                # print("Length: %2d" % (rowLength))
                if rowLength < 20:
                    # move to next row if insufficient data
                    print("Insufficient data! Length: %2d" % (rowLength))
                    print(row)
                    continue

                # for i in range(0, len(row), 1):
                for i in range(rowLength):
                    # print("%2d = %s" % (i, row[i]))
                    value = row[i]

                    try:
                        # convert to particular data-type
                        if i in indexRange:
                            if value != "" and value.isnumeric():
                                value = int(value)
                            else:
                                value = 0
                        elif i == 22:
                            if value == "" or not value.isnumeric():
                                value = 0;
                            else:
                                value = int(value)
                        elif value == 'true':
                            value = 1
                        elif value == 'false':
                            value = 0
                        else:
                            if value.find("'") != -1:
                                value =  value.replace("'", "''")

                            value = "'%s'" % (value,)

                    except ValueError:
                        print('file {}, line {}: {}, row:{}'.format(filename, reader.line_num, e, row))

                    # append value
                    values.append(value)

                # print(values)
                # sql = "%s%s%s" % (sqlPrefix, ",".join(values), sqlSuffix,)
                # sql = "%s%s%s" % (sqlPrefix, ','.join(map(str, values)) , sqlSuffix,)
                # sql = "\t(%s),\n" % (','.join(map(str, values)))
                sql = "INSERT INTO %s(%s) \nVALUES (%s);\n" % (tableName, ", ".join(columns), ','.join(map(str, values)))
                # print(sql)

                # write sql to file.
                # print('Writing SQL to file.')
                targetFile.write(sql)

    except csv.Error as e:
        sys.exit('file {}, line {}: {}'.format(filename, reader.line_num, e))

    finally:
        # close csv file.
        print('Closing source file.')
        csvFile.close()

        # close target file.
        print('Closing target file.')
        targetFile.close()




def audienceTargetingCSVGenerator(tableName, columns, sourceFilePath, targetFilePath):
    targetFile = codecs.open(targetFilePath, "w", "utf_8")

    indexRange = [0, 4, 10, 17]

    # Write Headers
    headers = "%s\n" % (", ".join(columns))
    targetFile.write(headers)
    #

    try:
        # Read file
        with open(sourceFilePath, encoding='utf-8') as csvFile:
            # _csv.Error: line contains NUL
            reader = csv.reader((line.replace('\0', '') for line in csvFile), delimiter='\t', quoting=csv.QUOTE_NONE)

            # Iterate entries of the file.
            for row in reader:
                values = []
                # print(row)
                rowLength = len(row)
                # print("Length: %2d" % (rowLength))
                if rowLength < 20:
                    # move to next row if insufficient data
                    print("Insufficient data! Length: %2d" % (rowLength))
                    print(row)
                    continue

                # for i in range(0, len(row), 1):
                for i in range(rowLength):
                    # print("%2d = %s" % (i, row[i]))
                    value = row[i]

                    try:
                        # convert to particular data-type
                        if i in indexRange:
                            if value != "" and value.isnumeric():
                                value = int(value)
                            else:
                                value = 0
                        elif i == 22:
                            if value == "" or not value.isnumeric():
                                value = 0;
                            else:
                                value = int(value)
                        elif value == 'true':
                            value = 1
                        elif value == 'false':
                            value = 0
                        else:
                            # if value.find("'") != -1:
                            #     value =  value.replace("'", "''")
                            value = "'%s'" % (value,)

                    except ValueError:
                        print('file {}, line {}: {}, row:{}'.format(filename, reader.line_num, e, row))

                    # append value
                    values.append(value)

                # print(values)
                # sql = "%s%s%s" % (sqlPrefix, ",".join(values), sqlSuffix,)
                # sql = "%s%s%s" % (sqlPrefix, ','.join(map(str, values)) , sqlSuffix,)
                # sql = "\t(%s),\n" % (','.join(map(str, values)))
                data = "%s\n" % (','.join(map(str, values)))
                # print(data)

                # write sql to file.
                # print('Writing SQL to file.')
                targetFile.write(data)

    except csv.Error as e:
        sys.exit('file {}, line {}: {}'.format(filename, reader.line_num, e))

    finally:
        # close csv file.
        print('Closing source file.')
        csvFile.close()

        # close target file.
        print('Closing target file.')
        targetFile.close()



# Starting Point
if __name__ == "__main__":
    tableName = "dsp_segment_classification"
    columns = ["segment_id", "name", "data_powered_by", "segment_classification", "unique_user_count", "type",
               "sub_type", "created_on", "created_at", "suu_cnt", "mdm_id", "mdm_name", "pixel_id", "segment_status",
               "created_by", "last_modified_at", "segment_category", "retention_days", "parent_segment_id",
               "last_modified_by",
               "is_deleted", "segment_subclassification", "is_targeted"]
    # sourceFilePath = "/Users/rlakra/Downloads/WorkData/Hive/dsp_segment_classification-copy.tsv"
    sourceFilePath = "/Users/rlakra/Downloads/WorkData/Hive/dsp_segment_classification.tsv"
    sqlFilePath = "/Users/rlakra/Downloads/WorkData/Hive/dsp_segment_classification.sql"
    csvFilePath = "/Users/rlakra/Downloads/WorkData/Hive/dsp_segment_classification.csv"

    print('Processing Excel Sheet ...')
    # audienceTargetingSQLGenerator(tableName, columns, sourceFilePath, sqlFilePath)
    audienceTargetingCSVGenerator(tableName, columns, sourceFilePath, csvFilePath)
    print('Processing Completed!')
