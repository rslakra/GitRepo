# coding: utf-8

from __future__ import unicode_literals

import csv
import sys
from fileinput import filename

import mysql.connector

# Register Custom Delimiter
csv.register_dialect('unixpwd', delimiter='\t', quoting=csv.QUOTE_NONE)


# The csv file might contain very huge fields, therefore increase the field_size_limit
# And avoids error: _csv.Error: field larger than field limit (131072)
# csv.field_size_limit(sys.maxsize)

# Install MySQL Connector
# pip install mysql-connector-python

# Opens the db connection
def openDatabaseConnection(hostName, dbName, dbUserName, dbPassword):
    return mysql.connector.connect(host=hostName,database=dbName,user=dbUserName,password=dbPassword)


# Executes the sql statement.
def executeStatement(connection, tableName, columns, values):
    try:
        cursor = connection.cursor()
        # %d is not supported in mysql, so use %s for all the fields.
        sql = "INSERT INTO %s(%s) \nVALUES %s" % (tableName, ", ".join(columns), ','.join('(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)' for _ in values))
        dbValues = [_ for row in values for _ in row]
        cursor.execute(sql, dbValues)
        connection.commit()
        print("[{}] Record(s) inserted successfully into [{}] table!".format(cursor.rowcount, tableName))
    except mysql.connector.DataError as ex:
        print("Failed to insert record into {} table! Error: {}".format(tableName, ex))
    finally:
        cursor.close()



# Builds Insert Statement
def insertSingleRow(tableName, columns, values):
    return "INSERT INTO %s(%s) \nVALUES (%s);\n" % (tableName, ", ".join(columns), ','.join(map(str, values)))



# Opens the db connection
def closeDatabaseConnection(connection):
    print("Closing DB connection ...")
    if connection.is_connected():
        connection.close()
        print("The MySQL DB connection is closed!")



def populateMySQLDatabaseWithAudienceTargeting(tableName, columns, sourceFilePath):
    maxBatchSize = 1000
    indexRange = [0, 4, 10, 17]

    # INSERT INTO tableName(columns)
    # VALUES
    #     (value_list_1),
    #     (value_list_2),
    #     ...
    #     (value_list_n);
    # sqlStart = "INSERT INTO %s(%s) \nVALUES \n" % (tableName, ", ".join(columns))

    try:
        # Open DB Connection
        connection = openDatabaseConnection('localhost', 'dsp', 'root', '')
        dbInfo = connection.get_server_info()
        print("Connected to MySQL Server:", dbInfo)

        # Read file
        with open(sourceFilePath, encoding='utf-8') as csvFile:
            # Read .CSV file
            # reader = csv.reader(csvFile, delimiter='\t')
            # reader = csv.reader(csvFile, delimiter='\t', quoting=csv.QUOTE_NONE)
            # _csv.Error: line contains NUL
            reader = csv.reader((line.replace('\0', '') for line in csvFile), delimiter='\t', quoting=csv.QUOTE_NONE)

            dbValues = []

            # Iterate entries of the file.
            for row in reader:
                # rowCount += 1
                values = []
                # print(row)
                rowLength = len(row)
                # print("Length: %2d" % (rowLength))
                if rowLength < 20:
                    # move to next row if insufficient data
                    print("Insufficient data! Length: %2d" % (rowLength))
                    print(row)
                    continue
                elif row[0] == 'segment_id': # Ignore header row
                    rowCount = 0
                    continue

                # for i in range(0, len(row), 1):
                for i in range(rowLength):
                    # print("%2d = %s" % (i, row[i]))
                    value = row[i]

                    try:
                        # convert to particular data-type
                        if i in indexRange:
                            if value != "" and value.isnumeric():
                                value = int(value)
                            else:
                                value = 0
                        elif i == 22:
                            if value == "" or not value.isnumeric():
                                value = 0;
                            else:
                                value = int(value)
                        elif value == 'true':
                            value = 1
                        elif value == 'false':
                            value = 0
                        else:
                            # if value.find("'") != -1:
                            #     value = value.replace("'", "''")

                            # value = "'%s'" % (value,)
                            # Remove unwanted double quotes (")
                            value = "%s" % (value,)

                    except ValueError as ex:
                        print('file {}, line {}: {}, row:{}'.format(filename, reader.line_num, ex, row))

                    # append value
                    values.append(value)

                # print(values)
                # sql = "%s%s%s" % (sqlPrefix, ",".join(values), sqlSuffix,)
                # sql = "%s%s%s" % (sqlPrefix, ','.join(map(str, values)) , sqlSuffix,)
                # sql = "\t(%s),\n" % (','.join(map(str, values)))
                # sql = insertSingleRow(tableName, columns, values)
                # print(sql)

                # write sql to file.
                # print('Writing SQL to file.')
                # targetFile.write(sql)
                # executeStatement(connection, tableName, sql)
                if len(dbValues) == maxBatchSize:
                    executeStatement(connection, tableName, columns, dbValues)
                    rowCount = 0
                    dbValues = []
                    # Current Record
                    dbValues.append(values)
                else:
                    dbValues.append(values)

            # insert last batch size if it's < maxBatchSize
            batchSize = len(dbValues)
            if batchSize > 0 and batchSize < maxBatchSize:
                executeStatement(connection, tableName, columns, dbValues)
                rowCount = 0
                dbValues = []

    except csv.Error as ex:
        sys.exit('file {}, line {}: {}'.format(filename, reader.line_num, ex))
    except mysql.connector.Error as error:
        print("Failed to insert record into {} table! Error: {}".format(tableName, error))

    finally:
        # close csv file.
        print('Closing source file.')
        csvFile.close()

        # close db connection.
        closeDatabaseConnection(connection)



# Starting Point
if __name__ == "__main__":
    tableName = "dsp_segment_classification"
    columns = ["segment_id", "name", "data_powered_by", "segment_classification", "unique_user_count", "type",
               "sub_type", "created_on", "created_at", "suu_cnt", "mdm_id", "mdm_name", "pixel_id", "segment_status",
               "created_by", "last_modified_at", "segment_category", "retention_days", "parent_segment_id",
               "last_modified_by",
               "is_deleted", "segment_subclassification", "is_targeted"]
    # sourceFilePath = "/Users/rlakra/Downloads/WorkData/Phoenix/20230623/dsp_segment_classification-small.tsv"
    sourceFilePath = "/Users/rlakra/Downloads/WorkData/Phoenix/20230623/dsp_segment_classification.tsv"

    print('Processing Excel Sheet ...')
    populateMySQLDatabaseWithAudienceTargeting(tableName, columns, sourceFilePath)
    print('Processing Completed!')
