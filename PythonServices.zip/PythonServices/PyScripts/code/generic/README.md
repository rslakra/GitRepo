# Generic Scripts

The generic scripts to resolve daily issues.

## Environment
```
python -V #Python 3.8.3
pip install openpyxl
```

## Generate Comma-Seperated CRM_CUSTOMER_ID from Excel Sheet

- Run the python script ```logCommaSeperatedCrmCustomerId.py```.

    The script reads the file name provided at line 60 (i.e. 'VAT ID update - Dec 21.xlsx') and prints the results on 
the console. The comma-seperated ```columnList:``` values can be used in the next query.

Then use the comma-seperated ```crm_customer_id``` in the following script:
```sql
select mdm_company_name, crm_customer_id, vat_id, id, mdm_id
from MB.advertiser
where crm_customer_id in (
-- Replace below given comma-seperated 'crm_customer_id' with new values.
'0013200001IIN6VAAX', '0013200001IJY5sAAH'
)
order by last_updated DESC
;
```


# Author

- Rohtash Singh Lakra
