from openpyxl import load_workbook


# Query
#
# select mdm_company_name, crm_customer_id, vat_id, id, mdm_id
# from MB.advertiser
# where crm_customer_id in (
# '0013200001IIN6VAAX', '0013200001IJY5sAAH'
# )
# order by last_updated DESC
# ;
#
# mapping = {
#     'A':( 'Customer Name',)
#     'B':( 'Customer Account Number',)
# }
#
# Response Payload
# '0013200001HlmPUAAZ', '0017V00001Sr6QuQAJ'
#

def buildExcel2Json(file_path, tab_name):
    wb = load_workbook(filename=file_path)
    ws = wb[tab_name]

    totalRows = len(ws['A'])
    print(f'totalRows: {totalRows}')

    columnList = []

    for row in range(totalRows):
        if row == 0: continue  # skip the first line (column name)

        # skip if first column is empty
        crmCustomerId = ws['B'][row].value
        if not crmCustomerId:
            print(f'Skipping Row: {row + 1}')
            continue

        customerName = ws['A'][row].value

        print(f'Processing Row: {row + 1}, crmCustomerId: {crmCustomerId}, customerName: {customerName}')

        # append payload
        columnList.append(crmCustomerId)

    # print columnList
    # listCrmCustomerIds = ",".join(columnList)
    # print(f'columnList: {json.dumps(listCrmCustomerIds, indent=4)}')
    listCrmCustomerIds = ", ".join(["'{}'".format(value) for value in columnList])
    print(f'columnList:\n {listCrmCustomerIds}')
    # wb.save(filename=file_path)


if __name__ == "__main__":
    print('Processing Excel Sheet ...')
    # buildExcel2Json('Gemini Invalid VAT IDs.xlsx', 'Sheet1')
    # buildExcel2Json('Gemini Update VAT IDs.xlsx', 'Sheet1')
    buildExcel2Json('VAT ID update - Dec 21.xlsx', 'Sheet1')
    print('Processing Completed!')
