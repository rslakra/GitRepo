package com.rslakra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJwtApplication {

    /**
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(SpringBootJwtApplication.class, args);
    }
}