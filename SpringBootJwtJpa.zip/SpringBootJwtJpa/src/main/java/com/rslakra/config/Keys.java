package com.rslakra.config;

/**
 * @author Rohtash Lakra
 * @created 5/18/20 2:11 PM
 */
public interface Keys {

    String ACCESS_TOKEN = "accessToken";
}
