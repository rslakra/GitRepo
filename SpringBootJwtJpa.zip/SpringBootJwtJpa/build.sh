#!/bin/bash
#Author:Rohtash Lakra
mvn clean package
echo
