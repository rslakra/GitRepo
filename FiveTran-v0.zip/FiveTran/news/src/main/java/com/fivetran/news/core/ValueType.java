package com.fivetran.news.core;

public enum ValueType {
    Int,
    String;
}
