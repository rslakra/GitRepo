package com.fivetran.news;

import java.time.LocalDate;

import com.fivetran.news.core.Record;
import com.fivetran.news.core.RecordUploader;
import com.fivetran.news.core.Table;
import com.fivetran.news.core.ValueType;

public class NewspaperUpdater {

	private static int counter = 0;
	private Table tableStories;
	private Table tableStoryCounts;

	/**
	 * Main connector logic. Should sync up to today and save state for subsequent
	 * syncs.
	 * 
	 * @param uploader interfaces with the Core
	 * @param api      interfaces with the Source
	 * @param state    is saved for subsequent syncs
	 */
	public void update(RecordUploader uploader, RealNewspaperApi api, NewspaperState state) {
        counter = state.lastOffset + 1;
		NewspaperResponse newspaperResponse = api.getStories(state.lastDate, 0).get();
		for (int i = 0; i < newspaperResponse.count; i++) {
			// stories table
			addStoriesRecord(counter++, uploader, newspaperResponse.stories.get(i));
		}
	}

	private void addStoriesRecord(int id, RecordUploader uploader, NewspaperStory story) {
		Record.Builder recordBuilder = new Record.Builder(createStoriesTable())
				.addInt("id", id)
				.addString(Schema.HEADLINE_COLUMN, story.headline)
				.addString(Schema.PUBLISH_DATE_COLUMN, DateUtil.dateToString(story.publishedOn));
		uploader.submit(recordBuilder.build());

		story.readsPerDay.forEach((countDate, count) -> {
			Record.Builder counteRecordBuilder = new Record.Builder(createStoryCountsTable())
					.addInt("storyId", id)
					.addString(Schema.COUNT_DATE_COLUMN, countDate)
					.addInt(Schema.COUNTS_COLUMN, count);
			uploader.submit(counteRecordBuilder.build());
		});

	}

	/**
	 * 
	 * @return
	 */
	private Table createStoriesTable() {
		if (tableStories == null) {
			tableStories = new Table.Builder(Schema.STORIES_TABLE_NAME).addColumn("id", ValueType.Int)
					.addColumn(Schema.HEADLINE_COLUMN, ValueType.String)
					.addColumn(Schema.PUBLISH_DATE_COLUMN, ValueType.String).build();
		}

		return tableStories;
	}

	/**
	 * 
	 * @return
	 */
	private Table createStoryCountsTable() {
		if (tableStoryCounts == null) {
			tableStoryCounts = new Table.Builder(Schema.STORY_COUNTS_TABLE_NAME)
					.addColumn("storyId", ValueType.Int, false, tableStories.columns.get("id"))
					.addColumn(Schema.COUNT_DATE_COLUMN, ValueType.String)
					.addColumn(Schema.COUNTS_COLUMN, ValueType.Int).build();
		}

		return tableStoryCounts;
	}
}
