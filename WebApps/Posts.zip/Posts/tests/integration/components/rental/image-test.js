import { module, test } from 'qunit';
import { setupRenderingTest } from 'posts/tests/helpers';
import { click, render } from '@ember/test-helpers';
import { hbs } from 'ember-cli-htmlbars';

module('Integration | Component | rental/image', function (hooks) {
  setupRenderingTest(hooks);

  test('it renders the given image', async function (assert) {
    // Set any properties with this.set('myProperty', 'value');
    // Handle any actions with this.set('myAction', function(val) { ... });

    await render(hbs`<Rental::Image
        src="assets/images/Profile.png"
        alt="Profile"/>
    `);

    assert
      .dom('.image img')
      .exists()
      .hasAttribute('src', 'assets/images/Profile.png')
      .hasAttribute('alt', 'Profile');
  });

  test('clicking on the component toggles its size', async function (assert) {
    // Set any properties with this.set('myProperty', 'value');
    // Handle any actions with this.set('myAction', function(val) { ... });

    await render(hbs`<Rental::Image
        src="assets/images/Profile.png"
        alt="Profile"/>
    `);

    assert.dom('button.image').exists();
    assert.dom('.image').doesNotHaveClass('large');
    assert.dom('.image small').hasText('Zoom In');

    await click('button.image');
    assert.dom('.image').hasClass('large');
    assert.dom('.image small').hasText('Zoom Out');

    await click('button.image');
    assert.dom('.image').doesNotHaveClass('large');
    assert.dom('.image small').hasText('Zoom In');
  });
});
