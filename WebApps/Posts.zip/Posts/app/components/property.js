import Component from '@glimmer/component';

export default class PropertyComponent extends Component {

}
