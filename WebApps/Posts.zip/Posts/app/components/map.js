import Component from '@glimmer/component';
import ENV from 'posts/config/environment';

const MAPBOX_API_URL =
  'https://api.mapbox.com/styles/v1/mapbox/streets-v11/static';

export default class MapComponent extends Component {
  get mapBoxAccessToken() {
    return encodeURIComponent(ENV.MAPBOX_ACCESS_TOKEN);
  }

  get mapSrc() {
    let { lng, lat, width, height, zoom } = this.args;
    let coordinates = `${lng},${lat},${zoom}`;
    let dimensions = `${width}x${height}`;
    let accessToken = `access_token=${this.mapBoxAccessToken}`;

    return `${MAPBOX_API_URL}/${coordinates}/${dimensions}@2x?${accessToken}`;
  }
}
