import Component from '@glimmer/component';
import { tracked } from '@glimmer/tracking';
import { action } from '@ember/object';

export default class PropertyImageComponent extends Component {
  @tracked isZoomedIn = false;

  @action toggleImage() {
    this.isZoomedIn = !this.isZoomedIn;
    // alert(this.isZoomedIn);
  }
}
