'use strict';

module.exports = {
  singleQuote: true,
};
