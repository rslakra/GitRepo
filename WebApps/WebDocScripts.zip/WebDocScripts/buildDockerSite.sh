#!/bin/bash
#Author: Rohtash Lakra
echo
USER_NAME=dockerlakra
APP_NAME=webdocs
WORKDIR=/srv/slate
docker run --rm --name $APP_NAME -v $(pwd)/build:$WORKDIR/build -v $(pwd)/source:$WORKDIR/source $USER_NAME/$APP_NAME build
echo
