#!/bin/bash
#Author: Rohtash Lakra
echo
USER_NAME=dockerlakra
APP_NAME=webdocs
docker build . -t $USER_NAME/$APP_NAME
echo
