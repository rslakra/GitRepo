#!/bin/bash
#Author: Rohtash Lakra
echo
SCRIPT_DIR=$(pwd)
WEB_DOCS_DIR=$(pwd)/../WebDocs
ln -sf $SCRIPT_DIR/buildDockerImage.sh $WEB_DOCS_DIR/buildDockerImage
ln -sf $SCRIPT_DIR/buildDockerSite.sh $WEB_DOCS_DIR/buildDockerSite
ln -sf $SCRIPT_DIR/pullDockerImage.sh $WEB_DOCS_DIR/pullDockerImage
ln -sf $SCRIPT_DIR/runDockerServer.sh $WEB_DOCS_DIR/runDockerServer
echo
