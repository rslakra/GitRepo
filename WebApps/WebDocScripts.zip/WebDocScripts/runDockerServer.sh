#!/bin/bash
#Author: Rohtash Lakra
# Access your site at http://localhost:4567 until you stop the running container process.
echo
USER_NAME=dockerlakra
APP_NAME=webdocs
WORKDIR=/srv/slate
PORT=4567
docker run --rm --name $APP_NAME -p $PORT:$PORT -v $(pwd)/source:$WORKDIR/source $USER_NAME/$APP_NAME serve
echo
