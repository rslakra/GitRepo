# from django.shortcuts import render

# Create your views here.

# Chapter 2
# from django.http import HttpResponse

# def home_page_view(request):
#     return HttpResponse("Hello World!")


# Chapter 3
from django.views.generic import TemplateView

# Home Page
class IndexPageView(TemplateView):
    template_name = "index.html"


# About-Us Page
class AboutPageView(TemplateView):
    template_name = "about-us.html"

