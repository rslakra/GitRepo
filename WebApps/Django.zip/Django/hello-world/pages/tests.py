# pages/tests.py
# from django.test import TestCase

# Create your tests here.

from django.test import SimpleTestCase
from django.urls import reverse


# Index Page Tests
class IndexPageTests(SimpleTestCase):

    # tests URL location for index page
    def test_url_exists_by_location(self):
        response = self.client.get("/")
        self.assertEquals(response.status_code, 200)

    # tests URL name for index page
    def test_url_exists_by_name(self):
        response = self.client.get(reverse("home"))
        self.assertEquals(response.status_code, 200)

    # tests template name for index page
    def test_template_by_name(self):
        response = self.client.get(reverse("home"))
        self.assertTemplateUsed(response, "index.html")


    ## tests template contents for index page
    def test_template_by_content(self):
        response = self.client.get(reverse("home"))
        self.assertContains(response, "<h1>Hello World!</h1>")


# About Page Tests
class AboutPageTests(SimpleTestCase):
    # tests URL location for about-us page
    def test_url_exists_by_location(self):
        response = self.client.get("/about-us")
        self.assertEquals(response.status_code, 200)

    # tests URL name for about-us page
    def test_about_page_exists_by_name(self):
        response = self.client.get(reverse("about-us"))
        self.assertEquals(response.status_code, 200)

    # tests template name for index page
    def test_template_by_name(self):
        response = self.client.get(reverse("about-us"))
        self.assertTemplateUsed(response, "about-us.html")


    ## tests template contents for index page
    def test_template_by_content(self):
        response = self.client.get(reverse("about-us"))
        self.assertContains(response, "<h1>About Us</h1>")


