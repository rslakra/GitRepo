#pages/urls.py
from django.urls import path
# Chapter 2
# from .views import home_page_view

# urlpatterns = [
#     path("", home_page_view, name="home"),
# ]

# Chapter 3

from .views import IndexPageView, AboutPageView

urlpatterns = [
    path("", IndexPageView.as_view(), name="home"),
    path("about-us", AboutPageView.as_view(), name="about-us"),
]
