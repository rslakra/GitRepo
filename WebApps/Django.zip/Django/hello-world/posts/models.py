# posts/models.py
from django.db import models

# Create your models here.

class Post(models.Model):
    content = models.TextField()


    # returns the string representation of this model
    def __str__(self):
        return self.content[:50]

