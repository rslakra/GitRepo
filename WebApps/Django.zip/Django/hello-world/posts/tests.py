# posts/tests.py
from django.test import TestCase
from django.urls import reverse
from .models import Post


# Create your tests here.
class PostTests(TestCase):

    @classmethod
    def setUpTestData(obj):
        obj.post = Post.objects.create(content="This is a test case!")

    # tests model contents of post
    def test_model_content(self):
        self.assertEquals(self.post.content, "This is a test case!")

    # tests URL location for post page
    def test_url_exists_by_location(self):
        response = self.client.get("/posts")
        self.assertEquals(response.status_code, 200)

    # tests URL name for about-us page
    def test_about_page_exists_by_name(self):
        response = self.client.get(reverse("posts"))
        self.assertEquals(response.status_code, 200)

    # tests template name for index page
    def test_template_by_name(self):
        response = self.client.get(reverse("posts"))
        self.assertTemplateUsed(response, "posts.html")


    # tests template contents for index page
    def test_template_by_content(self):
        response = self.client.get(reverse("posts"))
        self.assertContains(response, "<h1>Posts Dashboard</h1>")


    # tests posts page
    def test_posts_page(self):
        response = self.client.get(reverse("posts"))
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, "posts.html")
        self.assertContains(response, "This is a test case!")



