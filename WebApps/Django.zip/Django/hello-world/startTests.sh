# startTests.sh
#!/bin/bash
echo
python3 manage.py test
echo

