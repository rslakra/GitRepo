#!/bin/bash
echo
python3 manage.py runserver
echo

