# Banking-Project
This is a Bank Management application made with Nodejs and MongoDB


install node and mongodb, 
run "npm install" in project directory, 
run "node app.js" to start the project, 
Website  will be running at port 3000
