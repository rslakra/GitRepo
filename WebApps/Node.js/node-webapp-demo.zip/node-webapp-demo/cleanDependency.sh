#/bin/bash
#Author: Rohtash  Lakra
#
# Run Node.js Application
clear
rm -rf node_modules
echo
