var mongoose = require("mongoose");
var userSchema = mongoose.Schema({
    userId: Number,
    userName: String,
    password: String,
    userType: { type: String, default: "External" },

    email: String,
    phone: String,
    address: String,

    isInternal: { type: Boolean, default: false },
    roles: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Roles"
    }],

    isAdmin: { type: Boolean, default: false },

    authenticate: { type: Boolean, default: false }

});

module.exports = mongoose.model("User", userSchema);