# Banking-Project
The Bank Management Nodejs and MongoDB Application

## Setup Instructions
- Install Node and  MongoDB
- Run ```npm install``` in the project directory
- Run ```node app.js``` in the project directory

The banking website should be running at port ```3000```.



##  Install mongo (using docker image) on your machine
- docker pull mongo
- docker run --name docker-mongo -d docker-mongo:docker-mongo
- docker exec -it --name docker-mongo bash