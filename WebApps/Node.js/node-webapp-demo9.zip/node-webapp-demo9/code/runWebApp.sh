#/bin/bash
#Author: Rohtash  Lakra
#
# Run Node.js Application
clear
#node app.js
#Enable DEBUG mode of app
# DEBUG=* node app.js
# DEBUG=WebApp node app.js
# npm start
# npm run debug
# npm test
#
# Run as development settings
npm start

echo
