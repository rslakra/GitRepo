# Furn – Furniture E-commerce HTML5 Template

---

Furn is a latest, responsive HTML5 bootstrap 3 based template with moderate structural approach! This can be an astonishing Platform to boost your business extraordinarily to individuals. You will get variety of sections for your ecommerce website. We built up this eCommerce template with outstanding system of navigation among different sections and float effects. You can maintain your business with this super creative template. See our other stunning template list for your other business <br>
<a href="https://www.themesine.com/downloads/furn-free-ecommerce-html5-template/" target="_blank">Preview Link</a>

We would love to see how you use this amazing html5 template. You can notify us about your site by sending a mail to us. We will write a blog post to showcase the best examples.

## Preview

![free travel agency responsive html template](https://www.themesine.com/wp-content/uploads/edd/2018/05/furn-banner.jpg)

## Demo site

<a href="https://www.themesine.com/downloads/furn-free-ecommerce-html5-template/" rel="nofollow" target="_blank">Demo</a>

## Author

<a href="https://www.themesine.com" target="_blank">ThemeSINE</a>

## Other templates

<a href="https://www.themesine.com/downloads/vue-dashloon-vue-js-admin-dashboard/" rel="nofollow" target="_blank">DashLoon vue admin template</a>

## Credits:

- Twitter Bootstrap https://getbootstrap.com/docs/3.3/
- jQuery http://jquery.org
- Font Awesome http://fontawesome.io
- Owl Carousel https://owlcarousel2.github.io/OwlCarousel2/
- Bootsnav http://bootsnav.danurstrap.com/

## License

Copyright (c) 2018 ThemeSINE

Furn is licensed under The MIT License (MIT). Which means that you can use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the final products. But you always need to state that ThemeSINE is the original author of this template.
