// Place in header (do not use async or defer)
document.addEventListener('readystatechange', event => {
    switch (document.readyState) {
        case "loading":
            console.log("document.readyState: ", document.readyState,
                `- The document is still loading.`
            );
            break;
        case "interactive":
            console.log("document.readyState: ", document.readyState,
                `- The document has finished loading DOM. `,
                `- "DOMContentLoaded" event`
            );
            break;
        case "complete":
            console.log("document.readyState: ", document.readyState,
                `- The page DOM with Sub-resources are now fully loaded. `,
                `- "load" event`
            );
            showDefaultTab(event);
            break;
    }
});

function showDefaultTab(event) {
    // Get the element with id="default" and click on it
    // document.getElementById("default").click();
    // Get the element with class="default" and click on it
    // document.getElementsByClassName("default").click();

    // document.getElementsByClassName("default")[0].click
    var defaultTabLink = document.querySelector('.default')
    // var defaultTabLink = document.getElementsByClassName("default");
    if (defaultTabLink) {
        openCity(event, defaultTabLink.innerHTML);
        // defaultTabLink.click();
        //     defaultTabLink.className = defaultTabLink.className.replace(" active", "");
        //     document.getElementById(defaultTabLink.innerHTML).style.display = "block";
        //     event.currentTarget.className += " active";
    }
}

// show city tab
function openCity(event, cityName) {
    var tabContents = document.getElementsByClassName("tabContents");
    if (tabContents) {
        for (var i = 0; i < tabContents.length; i++) {
            tabContents[i].style.display = "none";
        }
    }

    var tabLinks = document.getElementsByClassName("tabLinks");
    if (tabLinks) {
        for (var i = 0; i < tabLinks.length; i++) {
            tabLinks[i].className = tabLinks[i].className.replace(" active", "");
        }
    }

    document.getElementById(cityName).style.display = "block";
    event.currentTarget.className += " active";
}
