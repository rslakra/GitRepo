/**
 * Open the sidebar.
 */
function openSidebar() {
    document.getElementById("main").style.marginLeft = "25%";
    document.getElementById("navSidebar").style.width = "25%";
    document.getElementById("navSidebar").style.display = "block";
    document.getElementById("btnSidebarNav").style.display = 'none';
}

/**
 * Closes the sidebar.
 */
function closeSidebar() {
    document.getElementById("main").style.marginLeft = "0%";
    document.getElementById("navSidebar").style.display = "none";
    document.getElementById("btnSidebarNav").style.display = "inline-block";
}
