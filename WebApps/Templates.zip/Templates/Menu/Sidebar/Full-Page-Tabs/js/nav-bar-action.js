/**
 * Open Selected Page.
 * 
 * @param {*} pageName 
 * @param {*} element 
 * @param {*} color 
 */
function openPage(pageName, element, color) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].style.backgroundColor = "";
    }

    document.getElementById(pageName).style.display = "block";
    element.style.backgroundColor = color;
}

/**
 * Add listener to call a function after document is loaded.
 */
document.addEventListener('DOMContentLoaded', function () {
    // alert("Ready!");

    // Get the element with id="defaultOpen" and click on it
    document.getElementById("defaultOpen").click();

    /**
     * On Click of Sidebar Link
     */
    // document.getElementById("sidenav").ele.onclick = function () {
    //     onSidebarClick()
    // };

    // /**
    //  * On Click of Sidebar Link
    //  */
    // function onSidebarClick(divName) {
    //     //your code goes here
    //     alert('Alert onSidebarClick!');

    //     var i, tabcontent, tablinks;
    //     tabcontent = document.getElementsByClassName("tabcontent");
    //     for (i = 0; i < tabcontent.length; i++) {
    //         tabcontent[i].style.display = "none";
    //     }
    //     tablinks = document.getElementsByClassName("tablink");
    //     for (i = 0; i < tablinks.length; i++) {
    //         tablinks[i].style.backgroundColor = "";
    //     }

    //     var pageName = document.getElementById(divName);
    //     if (pageName) {
    //         pageName.style.display = "block";
    //         pageName.style.backgroundColor = "#353532";
    //     }
    // }
}, false);
