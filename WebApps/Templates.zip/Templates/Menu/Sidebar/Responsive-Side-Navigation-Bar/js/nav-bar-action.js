/**
 * On Document Ready
 */
$(document).ready(function () {
    $(".hamburger").click(function () {
        $(".wrapper").toggleClass("collapse");
    });
});
