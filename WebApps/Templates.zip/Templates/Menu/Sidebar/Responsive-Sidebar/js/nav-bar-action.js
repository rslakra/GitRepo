var hamburger = document.querySelector("sidebar");
if (hamburger) {
    hamburger.addEventListener("click", function () {
        document.querySelector("a").classList.toggle("active");
    })
}

