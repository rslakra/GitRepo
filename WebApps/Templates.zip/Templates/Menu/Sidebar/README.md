# Sidebar



## References

- [Font Awesome](https://fontawesome.com/v4)
- [howto_css_sidenav_buttons](https://www.w3schools.com/howto/howto_css_sidenav_buttons.asp)
- [quote-request](https://www.bl.ink/quote-request)


## Authors
- Rohtash Lakra
