function openSidebar() {
    document.getElementById("navSidebar").style.display = "block";
}

function closeSidebar() {
    document.getElementById("navSidebar").style.display = "none";
}