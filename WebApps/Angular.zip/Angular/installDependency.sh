#/bin/bash
#Author: Rohtash  Lakra
#
# Run Node.js Application
clear
# npm init
npm install
echo