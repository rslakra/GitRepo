# express-microservice
A microservice application written in Nodejs - express, sequelize, mysql
