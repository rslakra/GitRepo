const config = {
	port: 3306,
	mysql: {
		host: '127.0.0.1',
		username: 'root',
		password: 'password',
		database: 'blogger'
	},
	blogAPI : "http://localhost:8080"
}

module.exports = config;