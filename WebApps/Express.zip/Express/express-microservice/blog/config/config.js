const config = {
	port: 3306,
	mysql: {
		host: '127.0.0.1',
		username: 'root',
		password: '',
		database: 'blogger'
	}
}

module.exports = config;