define({
  "name": "Blog API Documentation",
  "version": "1.0.0",
  "description": "documentation of blog API",
  "title": "Blog API",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-07-22T10:39:35.625Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
