ember generate acceptance-test Posts
