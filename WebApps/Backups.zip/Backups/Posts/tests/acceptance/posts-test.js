import { module, test } from 'qunit';
import { click, currentURL, visit } from '@ember/test-helpers';
import { setupApplicationTest } from 'ember-qunit';

module('Acceptance | posts', function (hooks) {
  setupApplicationTest(hooks);

  test('visiting /', async function (assert) {
    await visit('/');
    assert.strictEqual(currentURL(), '/');
    assert.dom('nav').exists();
    assert.dom('h1').hasText('Posts');
    assert.dom('h2').hasText('Welcome to Posts!');
    assert.dom('.jumbo a.button').hasText('About Us');

    await click('.jumbo a.button');
    assert.strictEqual(currentURL(), '/about-us');
  });

  test('visiting /about-us', async function (assert) {
    await visit('/about-us');
    assert.strictEqual(currentURL(), '/about-us');
    assert.dom('nav').exists();
    assert.dom('h1').hasText('Posts');
    assert.dom('h2').hasText('About Posts');
    assert.dom('.jumbo a.button').hasText('Contact Us');

    await click('.jumbo a.button');
    assert.strictEqual(currentURL(), '/contact-us');
  });

  test('visiting /contact-us', async function (assert) {
    await visit('/contact-us');
    assert.strictEqual(currentURL(), '/contact-us');
    assert.dom('nav').exists();
    assert.dom('h1').hasText('Posts');
    assert.dom('h2').hasText('Contact Us');
    assert.dom('.jumbo a.button').hasText('About Us');

    await click('.jumbo a.button');
    assert.strictEqual(currentURL(), '/about-us');
  });

  test('visiting /rentals', async function (assert) {
    await visit('/rentals');
    assert.strictEqual(currentURL(), '/rentals');
    assert.dom('nav').exists();
    assert.dom('h1').hasText('Posts');
    assert.dom('h2').hasText('Welcome to Rentals!');
    assert.dom('article').hasClass('rental');
  });

  test('visiting /properties', async function (assert) {
    await visit('/properties');
    assert.strictEqual(currentURL(), '/properties');
    assert.dom('nav').exists();
    assert.dom('h1').hasText('Posts');
    assert.dom('h2').hasText('Welcome to Properties!');
    assert.dom('article').hasClass('rental');
  });

  test('navigating using the nav-bar', async function (assert) {
    await visit('/');
    assert.strictEqual(currentURL(), '/');
    assert.dom('nav').exists();
    assert.dom('nav a.menu-index').hasText('Posts');
    assert.dom('nav a.menu-about').hasText('About Us');
    assert.dom('nav a.menu-contact').hasText('Contact Us');
    assert.dom('nav a.menu-rentals').hasText('Rentals');
    assert.dom('nav a.menu-properties').hasText('Real Estate');

    await click('nav a.menu-about');
    assert.strictEqual(currentURL(), '/about-us');

    await click('nav a.menu-contact');
    assert.strictEqual(currentURL(), '/contact-us');

    await click('nav a.menu-rentals');
    assert.strictEqual(currentURL(), '/rentals');

    await click('nav a.menu-properties');
    assert.strictEqual(currentURL(), '/properties');

    await click('nav a.menu-index');
    assert.strictEqual(currentURL(), '/');
  });
});
