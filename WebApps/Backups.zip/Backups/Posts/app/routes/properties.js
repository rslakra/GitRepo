import Route from '@ember/routing/route';

// https://guides.emberjs.com/release/tutorial/part-1/working-with-data/
// We want to start working towards a place where we can eventually fetch data from the server, and then render
// the requested data as dynamic content from the templates. In order to do that, we will need a place where we
// can write the code for fetching data and loading it into the routes.
// In Ember, route files are the place to do that.

const COMMUNITY_CATEGORIES = ['Condo', 'Townhouse', 'Apartment'];

export default class PropertiesRoute extends Route {
  async model() {
    let loadResponse = await fetch('/api/rentals.json');
    let { data } = await loadResponse.json();
    return data.map((model) => {
      let { attributes } = model;
      let type;

      if (COMMUNITY_CATEGORIES.includes(attributes.category)) {
        type = 'Community';
      } else {
        type = 'Standalone';
      }

      return { type, ...attributes };
    });
  }
}
