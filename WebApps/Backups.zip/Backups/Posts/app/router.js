import EmberRouter from '@ember/routing/router';
import config from 'posts/config/environment';

export default class Router extends EmberRouter {
  location = config.locationType;
  rootURL = config.rootURL;
  baseUrl = config.rootURL;
}

Router.map(function () {});

Router.map(function () {
  // this.route('about');
  this.route('about', { path: '/about-us' });
  this.route('contact', { path: '/contact-us' });
  this.route('rentals');
  this.route('properties');
  this.route('property', { path: '/property/:property_id' });
});
