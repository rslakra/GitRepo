export default function Tag(props) {
    return (
        <span className="chips has-bg-grey-400 is-grey-800 is-medium m-3">{props.name}</span>
    )
}
